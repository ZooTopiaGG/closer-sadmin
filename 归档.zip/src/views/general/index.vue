<template>
  <div class="wait">等待分配权限...</div>
</template>

<script>
export default {
  // 用户没分配页面时，跳转的页面
  // layout: "generaluser"
};
</script>
